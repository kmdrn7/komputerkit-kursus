<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QDetailMateri extends Model
{
	protected $table = "q_detail_materi";
	protected $primaryKey = "id_detail_materi";
	public $timestamps = false;
}
