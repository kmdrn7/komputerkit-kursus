<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QDetailTugas extends Model
{
	protected $table = "q_detail_tugas";
	protected $primaryKey = "id_detail_tugas";
	public $timestamps = false;
}
