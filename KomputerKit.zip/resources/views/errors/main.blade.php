ini adalah master layout dari error code
