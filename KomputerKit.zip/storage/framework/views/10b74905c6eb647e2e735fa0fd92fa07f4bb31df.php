<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    You are logged in!
					<br><br>
					<pre><?php echo e(Auth::guard('web')->user()); ?></pre>
                </div>
            </div>
        </div>
    </div>

	<example></example>

	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					Kursus 1 Teratas
				</div>

				<div class="panel-body">
					<div class="row ">
						<div class="col-md-12">
							<?php echo e(print_r($topFirst)); ?>

						</div>
						<div class="col-md-12">

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					Kursus 3 Teratas
				</div>

				<div class="panel-body">
					<div class="row ">
						<div class="col-md-12">
							<?php echo e(print_r($topThird)); ?>

						</div>
						<div class="col-md-12">

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					Masuk ke kelas
				</div>

				<div class="panel-body">
					<div class="row ">
						<a href="<?php echo e(route('kelas')); ?>" class="btn btn-warning">Masuk Kelas</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					Kuasai hal yang kamu sukai
				</div>

				<div class="panel-body">
					<div class="row ">
						<a href="<?php echo e(route('expert')); ?>" class="btn btn-warning">Lihat Expertise</a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					Semua Kursus
				</div>

				<div class="panel-body">
					<div class="row ">
						<?php $__currentLoopData = $kursus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php 
								$slug = $item->slug
							 ?>
							<a href="<?php echo e(route('kursus.free.id', $slug)); ?>" style="text-decoration: none; color: black;">
								<div class="col-md-4" style="padding: 10px; border: 1px solid">
									<h1><?php echo e($item->kursus); ?> <small style="font-size:12px"><?php echo e($item->waktu); ?> Hari</small></h1>
									<p>slug : <?php echo e($slug); ?></p>
									<p>Rp <?php echo e(number_format($item->harga, 0, ",", ".")); ?></p>
								</div>
							</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					Kursus yan diikuti
				</div>

				<div class="panel-body">
					<div class="row ">
						<?php echo e($id); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-body">
					<div class="row ">
						<a href="<?php echo e(route('kursus.id', ['id' => 'all'])); ?>" class="btn btn-primary">Kursus Berbayar</a>
						<a href="<?php echo e(route('kursus.free.id', ['kategori' => 'all'])); ?>" class="btn btn-success">Kursus Gratis</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>