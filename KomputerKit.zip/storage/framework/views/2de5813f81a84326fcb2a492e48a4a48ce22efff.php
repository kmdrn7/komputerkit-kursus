<?php $__env->startSection('content'); ?>
	Tugas : <?php echo e($tugas->tugas); ?> <br>
	Jawaban : <?php echo e($tugas->jawaban); ?> <br>
	Flag : <?php echo e($tugas->flag_tugas); ?> <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>