<?php $__env->startSection('content'); ?>
	<div class="container">

		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						Kategori
					</div>

					<div class="panel-body">
						<div class="row ">
							<a href="<?php echo e(route('kursus.free.id', ['id' => 'all'])); ?>" class="btn btn-primary">Semua</a>
							<?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo e(route('kursus.free.id', ['id' => $item->slug])); ?>" class="btn btn-primary"><?php echo e($item->kategori); ?></a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						Semua Kursus
					</div>

					<div class="panel-body">

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="search">Cari kursus</label>
								  <input type="text" class="form-control" id="search" name="search">
								</div>
							</div>
						</div><br>

						<div class="row ">
							<style media="screen">
							</style>
							<?php $__currentLoopData = $kursus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php 
									$slug = $item->slug
								 ?>
								<a href="<?php echo e(route('kursus.free.id', $slug)); ?>" style="text-decoration: none; color: black;">
									<div class="col-md-4" style="padding: 10px; border: 1px solid">
										<h1><?php echo e($item->kursus); ?></h1>
										<p>slug : <?php echo e($slug); ?></p>
										<p>Rp <?php echo e(number_format($item->harga, 0, ",", ".")); ?></p>
									</div>
								</a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/592fd699b3d02e11ecc67b97/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

	<script type="text/javascript">
		$(document).ready(function() {
			console.log("Berhasil");
			$('#search').on('keyup', function() {
				console.log($('#search').val());
			});
		});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>