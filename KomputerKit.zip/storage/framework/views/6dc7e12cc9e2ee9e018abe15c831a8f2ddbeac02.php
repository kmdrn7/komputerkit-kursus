<?php echo e($result->kursus); ?>

