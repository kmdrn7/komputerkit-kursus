<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>Kelas</h2>
			</div>
		</div>
				
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						Promosi
					</div>

					<div class="panel-body">
						<div class="row ">

						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						Aktifitas Terbaru
					</div>

					<div class="panel-body">
						<div class="row ">

						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						Kursus yang diikuti
					</div>

					<div class="panel-body">
						<div class="row ">
							<?php $__currentLoopData = $qkursus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if( $item->flag_kursus==1 ): ?>
									<a href="<?php echo e(route('kelas.kursus.materi', ['id' => $item->id_kursus.'--'.$item->id_detail_kursus])); ?>" class="btn btn-success"><?php echo e($item->kursus); ?> <small>(<?php echo e($item->waktu); ?> Hari) (<?php echo e($item->flag_kursus==1 ? 'Aktif' : 'Tidak aktif'); ?>)</small></a>
								<?php else: ?>
									<button class="btn btn-info"><?php echo e($item->kursus); ?> <small>(<?php echo e($item->waktu); ?> Hari) (<?php echo e($item->flag_kursus==1 ? 'Aktif' : 'Tidak aktif'); ?>)</small></button>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						Bookmark
					</div>

					<div class="panel-body">
						<div class="row ">
							<?php $__currentLoopData = $qbookmark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4">
									<h4 class="btn btn-info"><?php echo e($item->kursus); ?></h4>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>