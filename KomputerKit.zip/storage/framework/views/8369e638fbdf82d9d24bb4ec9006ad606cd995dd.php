<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				Nama Kursus : <?php echo e($kursus->kursus); ?> <br>
				Deskripsi : <br>
				<?php echo e($kursus->ket_kursus); ?> <br>
				Hari : <?php echo e($kursus->waktu); ?>

			</div>
			<br><br>
			<pre>
				Kursus yang mungkin sama :
				<?php $__currentLoopData = $kursus_lain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a href="<?php echo e(route('kursus.checkout.id', ['id' => $item->slug])); ?>"><?php echo e($item->kursus); ?> <?php echo e($item->waktu); ?> Hari</a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</pre>
		</div>

		<div class="row">
			<div class="col-md-12">
				<form action="<?php echo e(route('kursus.checkout.post', ['id' => $kursus->slug])); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" name="id_kursus" value="<?php echo e($kursus->id_kursus); ?>">
					<input type="text" name="bayar_kursus" value="<?php echo e($kursus->harga); ?>">
					<button type="submit" name="submit" class="btn btn-success">Ikuti Kursus</button>
				</form>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>