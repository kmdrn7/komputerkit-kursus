<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						Semua Kursus
					</div>

					<div class="panel-body">
						<div class="row ">
							<style media="screen">
							</style>
							<?php $__currentLoopData = $kursus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php 
									$slug = $item->slug
								 ?>
								<a href="<?php echo e(route('kursus.id', $slug)); ?>" style="text-decoration: none; color: black;">
									<div class="col-md-4" style="padding: 10px; border: 1px solid">
										<h1><?php echo e($item->kursus); ?> <small style="font-size:12px"><?php echo e($item->waktu); ?> Hari</small></h1>
										<p>slug : <?php echo e($slug); ?></p>
										<p>Rp <?php echo e(number_format($item->harga, 0, ",", ".")); ?></p>
									</div>
								</a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>