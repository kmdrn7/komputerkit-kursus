<?php $__env->startSection('content'); ?>
	Materi : <?php echo e($materi->materi); ?> <br>
	Deskripsi : <?php echo e($materi->desc_materi); ?> <br>
	Flag : <?php echo e($materi->flag_materi); ?> <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>