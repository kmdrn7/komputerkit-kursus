<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>ChatRoom</h2>
				<chat-log :messages="messages"></chat-log>
				<chat-composer v-on:messagesent="addMessage"></chat-composer>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>