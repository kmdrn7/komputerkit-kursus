<?php $__env->startSection('content'); ?>
	<div class="container">

		<div class="row">
			<div class="col-md-12">
				<a href="<?php echo e(route('kelas.kursus.materi', ['id' => $id])); ?>" class="btn btn-primary">Materi</a>
				<a href="<?php echo e(route('kelas.kursus.tugas', ['id' => $id])); ?>" class="btn btn-primary">Tugas</a>
				<a href="<?php echo e(route('kelas.kursus.diskusi', ['id' => $id])); ?>" class="btn btn-primary">Pesan</a>
			</div>
		</div>

		<br>
		<div class="row">
			<div class="col-md-12">
				<?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a href="<?php echo e(route('kelas.kursus.tugas.detail', ['id' => $item->id_kursus.'--'.$item->id_detail_kursus,'id_materi' => $item->id_detail_tugas])); ?>"><h3><?php echo e($item->tugas); ?></h3></a> <br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>