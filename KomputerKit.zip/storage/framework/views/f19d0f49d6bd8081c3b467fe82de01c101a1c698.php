ini adalah detail dari expert
